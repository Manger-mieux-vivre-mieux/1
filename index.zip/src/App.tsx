import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Sun, 
  Moon, 
  Apple, 
  Leaf, 
  Utensils, 
  Brain, 
  Heart, 
  Coffee, 
  Fish, 
  Salad, 
  ChevronRight,
  Instagram,
  Facebook,
  Twitter,
  Smile,
  Zap,
  Cloud
} from 'lucide-react';

// --- Components ---

const Preloader = () => (
  <motion.div 
    initial={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    className="fixed inset-0 z-50 flex items-center justify-center bg-wellness-pastel"
  >
    <div className="text-center">
      <motion.div
        animate={{ 
          rotate: [0, 10, -10, 0],
          y: [0, -10, 0]
        }}
        transition={{ repeat: Infinity, duration: 2 }}
        className="text-pink-400 mb-4"
      >
        <Leaf size={64} fill="currentColor" />
      </motion.div>
      <h2 className="text-xl font-medium text-pink-600">Manger mieux, vivre mieux...</h2>
    </div>
  </motion.div>
);

const Navbar = ({ darkMode, toggleDarkMode }: { darkMode: boolean, toggleDarkMode: () => void }) => {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <nav className={`fixed top-0 w-full z-40 transition-all duration-300 ${scrolled ? 'glass py-3 shadow-sm' : 'bg-transparent py-5'}`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <div className="text-2xl font-bold text-pink-600 tracking-tight">
          Manger mieux, vivre mieux
        </div>
        
        <div className="hidden md:flex items-center space-x-8">
          {['Accueil', 'Les bases', 'Idées de repas', 'Habitudes', 'Test'].map((item) => (
            <a 
              key={item} 
              href={`#${item.toLowerCase().replace(' ', '-')}`}
              className="text-pink-600 dark:text-pink-500 hover:text-pink-700 transition-colors font-semibold"
            >
              {item}
            </a>
          ))}
          <button 
            onClick={toggleDarkMode}
            className="p-2 rounded-full bg-gray-100 dark:bg-sky-100 text-pink-600 dark:text-pink-500 hover:bg-pink-100 transition-colors"
          >
            {darkMode ? <Sun size={20} /> : <Moon size={20} />}
          </button>
        </div>
      </div>
    </nav>
  );
};

const Hero = () => (
  <section id="accueil" className="relative min-h-screen flex items-center pt-20 overflow-hidden">
    <div className="absolute inset-0 z-0">
      <img 
        src="https://images.unsplash.com/photo-1490645935967-10de6ba17061?auto=format&fit=crop&q=80&w=2000" 
        alt="Healthy food background" 
        className="w-full h-full object-cover opacity-20 dark:opacity-10"
        referrerPolicy="no-referrer"
      />
      <div className="absolute inset-0 bg-gradient-to-b from-wellness-pastel/50 to-white dark:from-sky-100 dark:to-sky-50" />
    </div>

    <div className="max-w-7xl mx-auto px-6 relative z-10 grid md:grid-cols-2 gap-12 items-center">
      <motion.div
        initial={{ opacity: 0, x: -50 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.8 }}
      >
        <h1 className="text-5xl md:text-7xl font-bold text-pink-600 dark:text-pink-700 leading-tight mb-6">
          Apprendre à mieux manger <span className="text-pink-500">sans se priver</span>
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-400 mb-8 leading-relaxed">
          Bien manger, ce n'est pas se frustrer ou se contrôler tout le temps. 
          Le but, c'est surtout de trouver un équilibre et de se sentir mieux au quotidien. 
          Ce site est là pour t'aider à comprendre ton alimentation et adopter de meilleures habitudes, sans pression.
        </p>
        <div className="flex flex-wrap gap-4">
          <a href="#les-bases" className="px-8 py-4 bg-pink-500 text-white rounded-full font-semibold hover:bg-pink-600 transition-all shadow-lg shadow-pink-200 dark:shadow-none">
            Les bases
          </a>
          <a href="#idées-de-repas" className="px-8 py-4 bg-white dark:bg-gray-800 text-gray-800 dark:text-white rounded-full font-semibold border border-gray-200 dark:border-gray-700 hover:border-pink-300 transition-all">
            Idées de repas
          </a>
        </div>
      </motion.div>
      
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="relative"
      >
        <div className="w-full aspect-square rounded-full bg-pink-100 dark:bg-pink-900/20 absolute -z-10 blur-3xl opacity-60 animate-pulse" />
        <img 
          src="https://images.unsplash.com/photo-1543353071-873f17a7a088?auto=format&fit=crop&q=80&w=800" 
          alt="Healthy lifestyle" 
          className="rounded-3xl shadow-2xl rotate-3 hover:rotate-0 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
      </motion.div>
    </div>
  </section>
);

const Bases = () => (
  <section id="les-bases" className="py-24 bg-wellness-beige dark:bg-sky-100">
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <motion.h2 
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-4xl font-bold text-pink-600 dark:text-pink-700 mb-6"
        >
          Les bases de l'équilibre
        </motion.h2>
        <p className="max-w-2xl mx-auto text-gray-600 dark:text-gray-400">
          Manger équilibré, ce n'est pas compliqué. Il suffit d'avoir un peu de tout dans son assiette. 
          Le plus important, ce n'est pas d'être parfait mais d'être régulier.
        </p>
      </div>

      <div className="grid md:grid-cols-3 gap-8">
        {[
          { 
            title: 'Protéines', 
            icon: <Utensils className="text-pink-500" />, 
            desc: 'Essentielles pour vos muscles et votre satiété.',
            image: 'https://images.unsplash.com/photo-1551248429-40975aa4de74?auto=format&fit=crop&q=80&w=400'
          },
          { 
            title: 'Légumes', 
            icon: <Leaf className="text-green-500" />, 
            desc: 'Vitamines, fibres et minéraux à volonté.',
            image: 'https://images.unsplash.com/photo-1518843875459-f738682238a6?auto=format&fit=crop&q=80&w=400'
          },
          { 
            title: 'Féculents', 
            icon: <Apple className="text-orange-500" />, 
            desc: 'Votre source d\'énergie pour la journée.',
            image: 'https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=400'
          }
        ].map((item, i) => (
          <motion.div
            key={item.title}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.2 }}
            className="bg-white dark:bg-sky-50 rounded-3xl shadow-sm hover:shadow-xl transition-all border border-gray-100 dark:border-sky-200 overflow-hidden"
          >
            <div className="h-48 overflow-hidden">
              <img 
                src={item.image} 
                alt={item.title} 
                className="w-full h-full object-cover hover:scale-110 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
            </div>
            <div className="p-8">
              <div className="w-14 h-14 bg-wellness-pastel dark:bg-sky-100 rounded-2xl flex items-center justify-center mb-6">
                {item.icon}
              </div>
              <h3 className="text-xl font-bold mb-4 text-pink-600 dark:text-pink-700">{item.title}</h3>
              <p className="text-gray-600 dark:text-sky-800">{item.desc}</p>
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  </section>
);

const Repas = () => (
  <section id="idées-de-repas" className="py-24 bg-white dark:bg-sky-50">
    <div className="max-w-7xl mx-auto px-6">
      <div className="text-center mb-16">
        <h2 className="text-4xl font-bold text-pink-600 dark:text-pink-700 mb-4">Idées de repas simples</h2>
        <p className="text-gray-600 dark:text-gray-400">Pas besoin de faire compliqué pour bien manger.</p>
      </div>

      <div className="space-y-12">
        <div className="grid md:grid-cols-2 gap-8">
          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-wellness-pastel dark:bg-sky-100 p-8 rounded-3xl flex flex-col md:flex-row gap-6 items-center overflow-hidden"
          >
            <div className="w-32 h-32 rounded-2xl overflow-hidden shrink-0 shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&q=80&w=300" 
                alt="Petit-déjeuner" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-3 text-pink-600 dark:text-pink-700">Petit-déjeuner</h3>
              <ul className="space-y-2 text-gray-600 dark:text-sky-800">
                <li className="flex items-center gap-2"><ChevronRight size={16} className="text-pink-400" /> Yaourt nature + fruits + céréales</li>
                <li className="flex items-center gap-2"><ChevronRight size={16} className="text-pink-400" /> Pain complet + œufs + avocat</li>
              </ul>
            </div>
          </motion.div>

          <motion.div 
            whileHover={{ y: -5 }}
            className="bg-wellness-beige dark:bg-sky-100 p-8 rounded-3xl flex flex-col md:flex-row gap-6 items-center overflow-hidden"
          >
            <div className="w-32 h-32 rounded-2xl overflow-hidden shrink-0 shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1546069901-ba9599a7e63c?auto=format&fit=crop&q=80&w=300" 
                alt="Déjeuner" 
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <div>
              <h3 className="text-2xl font-bold mb-3 text-pink-600 dark:text-pink-700">Déjeuner</h3>
              <ul className="space-y-2 text-gray-600 dark:text-sky-800">
                <li className="flex items-center gap-2"><ChevronRight size={16} className="text-pink-400" /> Poulet + riz + légumes à volonté</li>
                <li className="flex items-center gap-2"><ChevronRight size={16} className="text-pink-400" /> Salade complète (protéines + légumes)</li>
              </ul>
            </div>
          </motion.div>
        </div>

        <motion.div 
          whileHover={{ y: -5 }}
          className="bg-pink-50 dark:bg-sky-100 p-8 rounded-3xl flex flex-col md:flex-row gap-6 items-center max-w-3xl mx-auto overflow-hidden"
        >
          <div className="w-32 h-32 rounded-2xl overflow-hidden shrink-0 shadow-lg">
            <img 
              src="https://images.unsplash.com/photo-1467003909585-2f8a72700288?auto=format&fit=crop&q=80&w=300" 
              alt="Dîner" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <h3 className="text-2xl font-bold mb-3 text-pink-600 dark:text-pink-700">Dîner</h3>
            <ul className="space-y-2 text-gray-600 dark:text-sky-800">
              <li className="flex items-center gap-2"><ChevronRight size={16} className="text-pink-400" /> Omelette + salade</li>
              <li className="flex items-center gap-2"><ChevronRight size={16} className="text-pink-400" /> Poisson + légumes</li>
            </ul>
          </div>
        </motion.div>
      </div>
      
      <p className="text-center mt-12 text-gray-500 italic">
        "Le but ici, c'est de rester simple. Pas besoin de faire compliqué pour bien manger."
      </p>
    </div>
  </section>
);

const Habitudes = () => (
  <section id="habitudes" className="py-24 bg-wellness-pastel dark:bg-sky-100">
    <div className="max-w-7xl mx-auto px-6">
      <div className="grid md:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
        >
          <h2 className="text-4xl font-bold text-pink-600 dark:text-pink-700 mb-8">Comprendre ses habitudes</h2>
          <p className="text-lg text-gray-600 dark:text-gray-400 mb-6 leading-relaxed">
            Parfois, on ne mange pas parce qu'on a faim, mais parce qu'on est stressé, fatigué ou ennuyé. 
            C'est normal, ça arrive à tout le monde. 
          </p>
          <p className="text-lg text-gray-600 dark:text-gray-400 mb-8 leading-relaxed">
            Le problème, ce n'est pas le manque de volonté, c’est souvent qu’on ne comprend pas pourquoi on agit comme ça. 
            Et c'est pour cette raison que ce site a été créé !
          </p>
          
          <div className="grid grid-cols-3 gap-4">
            {[
              { icon: <Zap className="text-yellow-500" />, label: 'Stress' },
              { icon: <Cloud className="text-blue-400" />, label: 'Fatigue' },
              { icon: <Smile className="text-pink-400" />, label: 'Émotions' }
            ].map((item) => (
              <div key={item.label} className="text-center p-4 bg-white dark:bg-gray-900 rounded-2xl shadow-sm">
                <div className="flex justify-center mb-2">{item.icon}</div>
                <span className="text-sm font-medium text-pink-600 dark:text-pink-500">{item.label}</span>
              </div>
            ))}
          </div>
        </motion.div>
        
        <div className="relative">
          <motion.div
            animate={{ 
              scale: [1, 1.05, 1],
              rotate: [0, 2, -2, 0]
            }}
            transition={{ repeat: Infinity, duration: 6 }}
            className="bg-white dark:bg-gray-900 p-12 rounded-[40px] shadow-2xl relative z-10"
          >
            <Brain size={80} className="text-pink-500 mb-6 mx-auto" />
            <h3 className="text-2xl font-bold text-center mb-4 text-pink-600 dark:text-pink-700">Écoutez votre corps</h3>
            <p className="text-center text-gray-500 dark:text-gray-400">
              Apprendre à différencier la faim physique de la faim émotionnelle est la première étape vers l'équilibre.
            </p>
          </motion.div>
          <div className="absolute -top-4 -right-4 w-full h-full bg-pink-200 dark:bg-pink-900/30 rounded-[40px] -z-10" />
        </div>
      </div>
    </div>
  </section>
);

const Test = () => {
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (message.trim()) {
      setSubmitted(true);
      setTimeout(() => setSubmitted(false), 5000);
    }
  };

  return (
    <section id="test" className="py-24 bg-white dark:bg-sky-50">
      <div className="max-w-3xl mx-auto px-6 text-center">
        <h2 className="text-4xl font-bold text-pink-600 dark:text-pink-700 mb-6">Parle-moi de ta journée</h2>
        <p className="text-gray-600 dark:text-gray-400 mb-12">
          Décris ce que tu manges ou ce que tu ressens, et je te donnerai quelques conseils simples.
        </p>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <textarea 
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Aujourd'hui, je me sens..."
            className="w-full p-6 rounded-3xl bg-wellness-beige dark:bg-gray-800 border-none focus:ring-2 focus:ring-pink-300 dark:focus:ring-pink-900 min-h-[200px] text-lg text-pink-900 dark:text-pink-100 transition-all"
          />
          
          <button 
            type="submit"
            className="glow-button w-full md:w-auto px-12 py-4 bg-pink-500 text-white rounded-full font-bold text-lg"
          >
            {submitted ? 'Conseils envoyés !' : 'Recevoir mes conseils'}
          </button>
        </form>
        
        <AnimatePresence>
          {submitted && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              className="mt-8 p-6 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-400 rounded-2xl"
            >
              Merci ! Prends un moment pour respirer, bois un verre d'eau et rappelle-toi que chaque petit pas compte.
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer className="py-12 bg-wellness-beige dark:bg-sky-100 border-t border-gray-100 dark:border-sky-200">
    <div className="max-w-7xl mx-auto px-6">
      <div className="flex flex-col md:flex-row justify-between items-center gap-8">
        <div className="text-xl font-bold text-pink-600">Manger mieux, vivre mieux</div>
        
        <div className="flex gap-6">
          <a href="#" className="text-gray-400 hover:text-pink-500 transition-colors"><Instagram /></a>
          <a href="#" className="text-gray-400 hover:text-pink-500 transition-colors"><Facebook /></a>
          <a href="#" className="text-gray-400 hover:text-pink-500 transition-colors"><Twitter /></a>
        </div>
        
        <div className="text-gray-500 text-sm">
          © 2026 Manger mieux, vivre mieux
        </div>
      </div>
      
      <div className="mt-8 flex flex-wrap justify-center gap-8 text-sm text-pink-600">
        <a href="#accueil" className="hover:text-pink-700">Accueil</a>
        <a href="#les-bases" className="hover:text-pink-700">Les bases</a>
        <a href="#idées-de-repas" className="hover:text-pink-700">Idées de repas</a>
        <a href="#habitudes" className="hover:text-pink-700">Habitudes</a>
        <button 
          onClick={() => window.print()} 
          className="hover:text-pink-700 font-bold flex items-center gap-1 no-print"
        >
          <Zap size={14} /> Version PDF
        </button>
      </div>
    </div>
  </footer>
);

// --- Main App ---

export default function App() {
  const [loading, setLoading] = useState(true);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setLoading(false), 2000);
    return () => clearTimeout(timer);
  }, []);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    document.documentElement.classList.toggle('dark');
  };

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-sky-50' : 'bg-white'}`}>
      <AnimatePresence>
        {loading && <Preloader />}
      </AnimatePresence>

      {!loading && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1 }}
        >
          <Navbar darkMode={darkMode} toggleDarkMode={toggleDarkMode} />
          <main>
            <Hero />
            <Bases />
            <Repas />
            <Habitudes />
            <Test />
          </main>
          <Footer />
        </motion.div>
      )}
    </div>
  );
}
